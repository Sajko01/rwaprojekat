export interface AuthState {
    isLoggedIn: boolean;
    nick?: string; // Dodaj nadimak kao opcionalno polje
  }
  
  export const initialState: AuthState = {
    isLoggedIn: false,
  };