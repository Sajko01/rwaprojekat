// auth.reducer.ts
import { createReducer, on } from '@ngrx/store';
import * as AuthActions from './auth.actions';
import { initialState, AuthState } from './auth.state';

export const authReducer = createReducer(
  initialState,
  on(AuthActions.login, (state, { nick }) => ({ ...state, isLoggedIn: true, nick })), // Dodaj nick u state
  on(AuthActions.logout, (state) => ({ ...state, isLoggedIn: false, nick: '' })) // Poništi nick prilikom logout-a
);
