import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-alert',
//   template: `
//     <h1 mat-dialog-title>Upozorenje</h1>
//     <div mat-dialog-content>
//       <p>{{ data.message }}</p>
//     </div>
//     <div mat-dialog-actions>
//       <button mat-button (click)="onClose()">Zatvori</button>
//     </div>
    
//   `,
  //styleUrls: ['./alert.component.scss']
  templateUrl: './alert.component.html',
  styleUrl: './alert.component.scss'
})
export class AlertComponent {
  constructor(
    public dialogRef: MatDialogRef<AlertComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { message: string }
  ) {}

  onClose(): void {
    this.dialogRef.close();
  }
}
