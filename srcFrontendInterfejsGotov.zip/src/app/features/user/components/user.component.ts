import { Component } from '@angular/core';
import { AuthDto, CreateCartDto, CreateUserDto } from '../interfaces/auth'; 
import { UserService } from '../services/user.service';
import { Store } from '@ngrx/store';
import { login } from '../../../auth/auth.actions';
import { CartService } from '../../cart/services/cart.service';
import { AuthState } from '../../../auth/auth.state';
import { logout } from '../../../auth/auth.actions';
import { selectIsLoggedIn, selectUserNick } from '../../../auth/auth.selectors';
import { async, firstValueFrom, Observable, of, switchMap, take } from 'rxjs';
import { AlertComponent } from '../alert/alert.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-user',
 // standalone: true,
  //imports: [],
  templateUrl: './user.component.html',
  styleUrl: './user.component.scss'
})
export class UserComponent {

  isLogin: boolean = true; // Kontrolira da li je forma za prijavu ili registraciju
  userDto: CreateUserDto = { email: '', password: '' , nick: '',address:''}; // Inicijalizacija objekta
  cartDto: CreateCartDto = { userEmail: '', location: '' };
  cartId:any=0;
  uNick:string;
  newLocation:string;
  //location: string = '';
  location$: Observable<{ location: string }> | null = null;

  isLoggedIn$: Observable<boolean>;

  userNick$: Observable<string | undefined>; // Posmatraj nadimak korisnika

  constructor(private userService: UserService,private store: Store<AuthState>,private cartService:CartService, private dialog: MatDialog) {
   // window.location.reload();
    this.isLoggedIn$ = this.store.select(selectIsLoggedIn);
    this.userNick$ = this.store.select(selectUserNick); // Selektuj nadimak

    //this.cartId=0;
  this.uNick='';
  this.newLocation="";

  this.userNick$
  .pipe(
    // Kada dobiješ email, koristi ga da dobiješ ID korpe
    switchMap((email) => {
      if (email) {
        // Pozivamo servis da dobijemo Cart ID na osnovu email-a
       
        return this.cartService.getCartForUser(email);
      } else {
        // Ako nema email-a, vraćamo prazan Observable
        return of(null);
      }
    })
  )
  .subscribe({
    next: (cartId) => {
      if (cartId) {
        this.cartId = cartId;  // Postavi cartId ako je pronađena korpa


        // this.cartService.getCartLocationById(this.cartId).subscribe(//za prikaz mi treba 
        //   (response) => {
        //     this.location$  = response.location;
        //   },
        //   (error) => {
        //     console.error('Error fetching cart location', error);
        //   }
        // );
        this.location$ = this.cartService.getCartLocationById(this.cartId);



      } else {
        this.cartId = 0;  // Ako nije pronađena korpa, postavi cartId na 0
      }
    },
    error: (error) => {
      console.error('Greška prilikom dobijanja ID-a korpe:', error);
      this.cartId = 0;  // U slučaju greške postavi cartId na 0
    }
  });
  
 

  }

  logout() {
    // Ukloni token iz lokalne memorije (ili gde god ga čuvaš)
    ///PROVERAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
    localStorage.removeItem('authToken'); 
    window.location.reload();
    this.store.dispatch(logout());
  

  }

  ngOnInit(){
  //  window.location.reload();
  }


  toggleForm() {
    this.isLogin = !this.isLogin; // Prebacuje između prijave i registracije
  }
   
  
  
  onLocationUpdate(){

    this.userNick$
  .pipe(
    // Kada dobiješ email, koristi ga da dobiješ ID korpe
    switchMap((email) => {
      if (email) {
        // Pozivamo servis da dobijemo Cart ID na osnovu email-a
        return this.cartService.getCartForUser(email);
      } else {
        // Ako nema email-a, vraćamo prazan Observable
        return of(null);
      }
    })
  )
  .subscribe({
    next: (cartId) => {
      if (cartId) {
        this.cartId = cartId;

        // Sada možemo da pozovemo funkciju za ažuriranje lokacije korpe
        this.cartService.updateCartLocation(this.cartId, this.newLocation).subscribe({
          next: (response) => {
            console.log('Lokacija korpe uspešno ažurirana:', response);
            this.location$ = this.cartService.getCartLocationById(this.cartId);
          },
          error: (error) => {
            console.error('Greška prilikom ažuriranja lokacije:', error);
          }
        });
      } else {
        console.error('Korpa nije pronađena ili email nije dostupan.');
      }
    },
    error: (error) => {
      console.error('Greška prilikom dobijanja ID-a korpe:', error);
    }
  });

  }
  

  onAddressSubmit(loc:string) {
    //console.log(this.cartService.getCartForUser("sajko@com"));
   // this.userNick$.pipe(take(1)).subscribe(userEmail => {
      this.cartDto.userEmail = this.userDto.email || '';   //PAZI OVO SAM IZMENIO!!!!!!!!!!!!!! NE UZIMA PREKO NgRX
      //this.cartDto.location=loc;
      this.cartDto.location=loc;
      console.log(this.cartDto.location+this.cartDto.userEmail)
      this.cartService.create(this.cartDto).subscribe(
        (cart) => {
          this.cartId=cart.id
          console.log('Korpa je kreirana:', cart);/////////////////////////////////////////////////////////////////////////////////////////

         




        },
        (error) => {
          console.error('Greška prilikom kreiranja korpe:'+this.cartDto.userEmail+this.cartDto.location, error);
        }
      );
    //});
  }

  onSubmit( ) {
    if (this.isLogin) {

      //window.location.reload();
      const authData: AuthDto = { email: this.userDto.email, password: this.userDto.password,nick:this.userDto.nick};
      this.userService.login(authData).subscribe(
        (response) => {
          console.log('Uspesno prijavljen', response);
          this.store.dispatch(login({ nick: response.email })); // Proslijedi nick
        },
        (error) => {
          console.error('Greska prilikom prijave:', error);
          this.openAlertDialog('Neuspešna prijava. Proverite email i lozinku!');
        }
      );
    } else {
      ///////////////////////////////////////////////////////////////////////////////////////////
      if (!this.isValidEmail(this.userDto.email)) {
        this.openAlertDialog('Neispravan email');
        return;
      }
  
      if (!this.isValidPassword(this.userDto.password)) {
        this.openAlertDialog('Lozinka mora imati bar 8 karaktera i bar jedan broj!');
        return;
      }
      if(this.userDto.address=='')
      {
        this.openAlertDialog('Unesite adresu!');
        return;

      }
      this.userService.createUser(this.userDto).subscribe(
        (response) => {
         //this.cartDto.location=loc;
         this.onAddressSubmit(this.userDto.address);
         
          console.log('Uspesno registrovan', response),
          this.toggleForm();
         },

         (error) => {
          console.error('Greska prilikom registracije:', error);
          this.openAlertDialog('Greška prilikom registracije! Pokušajte ponovo.');
        }
      );
    }
  }
  












  isValidEmail(email: string): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }
  
  isValidPassword(password: string): boolean {
    return password.length >= 8 && /[0-9]/.test(password);
  }
  
  openAlertDialog(message: string): void {
    this.dialog.open(AlertComponent, {
      data: { message: message },
    });

}}
