export interface User{
    id: number;
    nick?: string;
    email?: string;
    addres?:string;
    password?: string;
}