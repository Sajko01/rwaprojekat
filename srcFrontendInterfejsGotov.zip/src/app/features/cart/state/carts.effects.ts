// import { Injectable } from '@angular/core';
// import { Actions, createEffect, ofType } from '@ngrx/effects';
// import { CartService } from '../services/cart.service';
// import { addItem, removeItem, updateQuantity } from './carts.actions';
// import { map, switchMap } from 'rxjs/operators';
// import { of } from 'rxjs';

// @Injectable()
// export class CartEffects {
//   constructor(private actions$: Actions, private cartService: CartService) {}

//   addItem$ = createEffect(() =>
//     this.actions$.pipe(
//       ofType(addItem),
//       switchMap(action => this.cartService.addItem(action.item).pipe(
//         map(() => ({ type: '[Cart API] Add Item Success' }))
//       ))
//     )
//   );

//   removeItem$ = createEffect(() =>
//     this.actions$.pipe(
//       ofType(removeItem),
//       switchMap(action => this.cartService.removeItem(action.id).pipe(
//         map(() => ({ type: '[Cart API] Remove Item Success' }))
//       ))
//     )
//   );

//   updateQuantity$ = createEffect(() =>
//     this.actions$.pipe(
//       ofType(updateQuantity),
//       switchMap(action => this.cartService.updateItem(action.id, action.quantity).pipe(
//         map(() => ({ type: '[Cart API] Update Quantity Success' }))
//       ))
//     )
//   );
// }
