// import { createReducer, on } from '@ngrx/store';
// import { CartItem } from '../../interfaces/cart-item.interface';
// import { addItem, removeItem, updateQuantity } from './cart.actions';

// export interface CartState {
//   items: CartItem[];
// }

// export const initialState: CartState = {
//   items: []
// };

// export const cartReducer = createReducer(
//   initialState,
//   on(addItem, (state, { item }) => ({
//     ...state,
//     items: [...state.items, item]
//   })),
//   on(removeItem, (state, { id }) => ({
//     ...state,
//     items: state.items.filter(item => item.id !== id)
//   })),
//   on(updateQuantity, (state, { id, quantity }) => ({
//     ...state,
//     items: state.items.map(item =>
//       item.id === id ? { ...item, quantity: +quantity } : item
//     )
//   }))
// );
