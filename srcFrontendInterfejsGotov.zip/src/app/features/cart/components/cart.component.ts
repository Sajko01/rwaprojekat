import { ChangeDetectorRef, Component } from '@angular/core';
import { CartItem } from '../interfaces/cart';
import { CartService } from '../services/cart.service';
import { selectIsLoggedIn, selectUserNick } from '../../../auth/auth.selectors';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, map, Observable, of, switchMap, tap } from 'rxjs';
import { Store } from '@ngrx/store';
import { AuthState } from '../../../auth/auth.state';
import { CreateOrderDto } from '../../orders/interfaces/order';
import { OrderService } from '../../orders/services/order.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  // standalone: true,
  // imports: [],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.scss'
})
export class CartComponent {
  
  cartItems: CartItem[] = [];
  cartId: number=0;
  userEmail: string = '';
  totalPrice: number | null = null;
  cartIsEmpty$: Observable<boolean>| null = null; 
  private orderMakedSubject = new BehaviorSubject<boolean>(false);
  orderMaked$ = this.orderMakedSubject.asObservable();
  orderInfo: string = ''; 
  



  
  isLoggedIn$: Observable<boolean>;
  userNick$: Observable<string | undefined>; // Posmatraj nadimak korisnika

  constructor(private store: Store<AuthState>,private http: HttpClient,private cartService:CartService,private orderService: OrderService,private router:Router) {
    this.isLoggedIn$ = this.store.select(selectIsLoggedIn);
    this.userNick$ = this.store.select(selectUserNick); // Selektuj nadimak



   
  
  }
  scrollToProducts() {
    // Prebaci se na stranicu sa proizvodima
    this.router.navigate(['/products']).then(() => {
      // Nakon navigacije, koristi setTimeout kako bi sačekao da se stranica učita
      setTimeout(() => {
        const element = document.getElementById('products-section');
        if (element) {
          const yOffset = -40; // Offset od 70px
          const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
          window.scrollTo({ top: yPosition, behavior: 'smooth' });
        }
      }, 200); // Sačekaj 0 milisekundi, ali dovoljno da se DOM učita
    });
  }

  scrollToServices() {
    // Prebaci se na stranicu sa proizvodima
    this.router.navigate(['/services']).then(() => {
      // Nakon navigacije, koristi setTimeout kako bi sačekao da se stranica učita
      setTimeout(() => {
        const element = document.getElementById('services-section');
        if (element) {
          const yOffset = -100; // Offset od 70px
          const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
          window.scrollTo({ top: yPosition, behavior: 'smooth' });
        }
      }, 200); // Sačekaj 0 milisekundi, ali dovoljno da se DOM učita
    });
  }

  scrollToOrders() {
    // Prebaci se na stranicu sa proizvodima
    this.router.navigate(['/orders']).then(() => {
      // Nakon navigacije, koristi setTimeout kako bi sačekao da se stranica učita
      setTimeout(() => {
        const element = document.getElementById('order-section');
        if (element) {
          const yOffset = 0; // Offset od 70px
          const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
          window.scrollTo({ top: yPosition, behavior: 'smooth' });
        }
      }, 200); // Sačekaj 0 milisekundi, ali dovoljno da se DOM učita
    });
  }


  ngOnInit(): void {
    this.cartIsEmpty$ = this.checkIfCartIsEmpty();
    this.orderMakedSubject.next(false);

    this.userNick$
      .pipe(
        // Kada dobiješ email, koristi ga da dobiješ ID korpe
        switchMap((email) => {
          if (email) {
            return this.cartService.getCartForUser(email); // Pozivamo servis da dobijemo Cart ID na osnovu email-a
          } else {
            return of(null); // Ako nema email-a, vraćamo prazan Observable
          }
        })
      )
      .subscribe({
        next: (cartId) => {
          if (cartId) {
            this.cartId = cartId;  // Postavi cartId ako je pronađena korpa
            this.loadCartItems(this.cartId);  // Sada, nakon postavljanja cartId, pozovi funkciju za učitavanje stavki korpe
          } else {
            this.cartId = 0;  // Ako nije pronađena korpa, postavi cartId na 0
          }
        },
        error: (error) => {
          console.error('Greška prilikom dobijanja ID-a korpe:', error);
          this.cartId = 0;  // U slučaju greške postavi cartId na 0
        }
      });
  }

  updateQuantity(cartItemId: number, newQuantity: number): void {
    this.cartService.updateCartItemQuantity(cartItemId, newQuantity)
      .subscribe({
        next: (updatedItem) => {
          console.log('Količina ažurirana:', updatedItem);
          this.ngOnInit()





          
          //this.loadCartItems(this.cartId);//PROVERIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII  NGRX PLIS
          // Ovdje možeš dodati logiku za osvežavanje prikaza stavki u korpi
          //this.loadCartItems(); // Opcionalno: ponovo učitaj stavke
        },
        error: (error) => {
          console.error('Greška prilikom ažuriranja količine:', error);
        }
      });
  }
  

  deleteCartItems( productId: number,productOrService:boolean) {
    

    this.userNick$
      .pipe(
        // Kada dobiješ email, koristi ga da dobiješ ID korpe
        switchMap((email) => {
          if (email) {
            return this.cartService.getCartForUser(email); // Pozivamo servis da dobijemo Cart ID na osnovu email-a
          } else {
            return of(null); // Ako nema email-a, vraćamo prazan Observable
          }
        })
      )
      .subscribe({
        next: (cartId) => {
          if (cartId) {
            this.cartId = cartId;  // Postavi cartId ako je pronađena korpa

            if (productOrService) {
              // Ako postoji productOrService, pozovi delete za productId
              this.cartService.deleteCartItemsByCartAndProductId(this.cartId, productId).subscribe({
                next: (response) => {
                  console.log('Uspešno obrisano:', response);
                  this.cartItems = this.cartItems.filter(item => item.product?.id !== productId);
                },
                error: (err) => {
                  console.error('Greška prilikom brisanja:', err);
                },
              });
            } else {
              // Ako productOrService ne postoji, pozovi neku drugu logiku (ili čak isti delete, ako je potrebno)
              this.cartService.deleteCartItemsByCartAndServiceId(this.cartId, productId).subscribe({
                next: (response) => {
                  console.log('Uspešno obrisano:', response);
                  this.cartItems = this.cartItems.filter(item => item.service?.id !== productId);
                },
                error: (err) => {
                  console.error('Greška prilikom brisanja:', err);
                },
              });
            }


            
            // this.cartService.deleteCartItemsByCartAndProductId(this.cartId, productId).subscribe({
            //   next: (response) => {
            //     console.log('Uspešno obrisano:', response);
            //     // Osvježavanje prikaza
            //     this.cartItems = this.cartItems.filter(item => item.product?.id !== productId);
            //     //this.cd.detectChanges(); // Osvježi UI
            //   },
            //   error: (err) => {
            //     console.error('Greška prilikom brisanja:', err);
            //   },
            // });
             
          } 
        },
        error: (error) => {
          console.error('Greška prilikom brisanja stavke:', error);
          this.cartId = 0;  // U slučaju greške postavi cartId na 0
        }
      });
       

      //this.checkProductInCart(productId);


      this.cartIsEmpty$ = this.checkIfCartIsEmpty();
    
  }

  


  // constructor(
  //   private cartService: CartService,
  //   private route: ActivatedRoute
  // ) {}

  // ngOnInit(): void {

  //   this.userNick$
  //   .pipe(
  //     // Kada dobiješ email, koristi ga da dobiješ ID korpe
  //     switchMap((email) => {
  //       if (email) {
  //         // Pozivamo servis da dobijemo Cart ID na osnovu email-a
  //        // console.log("Nesto");
  //         return this.cartService.getCartForUser(email);
          
  //       } else {
  //         // Ako nema email-a, vraćamo prazan Observable
  //         //console.log("nista");
  //         return of(null);
  //       }
  //     })
  //   )
  //   .subscribe({
  //     next: (cartId) => {
  //       if (cartId) {
  //         this.cartId = cartId;  // Postavi cartId ako je pronađena korpa
  //         //console.log("Nesto"+this.cartId);
  //       } else {
  //         this.cartId = 0;  // Ako nije pronađena korpa, postavi cartId na 0
  //       }
  //     },
  //     error: (error) => {
  //       console.error('Greška prilikom dobijanja ID-a korpe:', error);
  //       this.cartId = 0;  // U slučaju greške postavi cartId na 0
  //       console.log("Nista"+this.cartId);
  //     }
  //   });


    
  //   //console.log("Nesto3"+this.cartId);
  //     this.loadCartItems(this.cartId);
  //   }
  

  loadCartItems(cartId: number): void {
    this.cartService.getCartItems(cartId).subscribe(
      (items: CartItem[]) => {
        this.cartItems = items.map(item => ({
          ...item,
          tempQuantity: item.quantity  // Postavi tempQuantity na početnu količinu
        }));
      
      },
      (error) => {
        console.error('Error fetching cart items:', error);
      }
    );
  }

  checkIfCartIsEmpty(): Observable<boolean> {
    return this.userNick$.pipe(
      switchMap((email) => {
        if (email) {
          return this.cartService.getCartForUser(email); // Dobijamo Cart ID na osnovu email-a
        } else {
          return of(null); // Ako nema email-a, vraćamo prazan Observable
        }
      }),
      switchMap((cartId) => {
        console.log(cartId); // Ispisujemo cartId za debagovanje
        if (cartId) {
          // Pozivamo backend servis da proverimo da li je korpa prazna
          return this.cartService.isCartEmpty(cartId).pipe(
            tap(response => console.log('Response from isCartEmpty:', response)), 
            map(response => response.isEmpty) // Vraćamo samo boolean vrednost
          );
        } else {
          return of(true); // Ako nema cartId, vraćamo true kao da je prazna
        }
      })
    );
  }

  submitOrder() {
    // Pretpostavljamo da userNick$ već postoji i daje email korisnika
    this.userNick$
      .pipe(
        // Kada dobiješ email, koristi ga da dobiješ ID korpe
        switchMap((email) => {
          if (email) {
            this.userEmail =email ;
            return this.cartService.getCartForUser(email); // Pozivamo servis da dobijemo Cart ID na osnovu email-a
          } else {
            return of(null); // Ako nema email-a, vraćamo prazan Observable
          }
        })
      )
      .subscribe({
        next: (cartId) => {
          if (cartId) {
            this.cartId = cartId;  // Postavi ID korpe
             // Pretpostavljamo da u Cart objektu imaš i userId
            this.totalPrice = 0; // Preuzmi ukupnu cenu iz korpe ako je dostupna
            
            // Kreiraj DTO za narudžbinu
            const orderDto: CreateOrderDto = {
              id: 0, // Automatski generisano
              userEmail: this.userEmail,
              cartId: this.cartId,
              totalPrice: this.totalPrice || 0, // Ako nije definisana, postavi na 0
              orderDate: new Date(),
              orderInfo: this.orderInfo // dodaj napomene
            };

            // Pozovi servis da kreira narudžbinu
            this.orderService.createOrder(orderDto).subscribe({
              next: (response) => {
                if (this.cartId !== null) { // Proveri da li je cartId validan
                  this.cartService.deleteCartItemsByCartId(this.cartId).subscribe({
                    next: () => {
                      this.orderMakedSubject.next(true);
                      this.loadCartItems(this.cartId);
                      console.log('Cart items successfully deleted and order maked');
                    },
                    error: (error) => {
                      console.error('Error deleting cart items', error);
                    }
                  });
                } else {
                  console.error('Cart ID is null, cannot delete items');
                }
              },
              error: (error) => {
                console.error('Error creating order', error);
              }
            });
          }
        },
        error: (error) => {
          console.error('Error fetching cart', error);
        }
      });
  }












  

  getImageUrl(imagePath: string): string {
    return `http://localhost:3000/img/${imagePath}`;
  }


}
