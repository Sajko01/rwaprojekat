import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreateOrderDto, OrderDto } from '../interfaces/order';
//import { CreateOrderDto } from '../interfaces/create-order.dto'; // Pretpostavljamo da postoji DTO interfejs

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private apiUrl = 'http://localhost:3000/order'; // Zameni pravom URL-om

  constructor(private http: HttpClient) { }

  createOrder(order: CreateOrderDto): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}`, order);
  }

  getOrdersByUserEmail(userEmail: string): Observable<OrderDto[]> {
    return this.http.get<OrderDto[]>(`${this.apiUrl}/user-order-items/${userEmail}`);
  }

  deleteOrderById(orderId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${orderId}`);
  }
}