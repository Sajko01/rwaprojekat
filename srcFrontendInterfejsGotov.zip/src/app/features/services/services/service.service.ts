import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root',
})
export class ServiceService {
  private endpoint = 'http://localhost:3000/service';
  constructor(private http: HttpClient) { }

//   public getProgrammers() {
//     return this.http.get<Programmer[]>(this.endpoint + '/getProgrammers');
//   }

//   public getProgrammer(id: number) {
//     return this.http.get<Programmer>(this.endpoint, { params: { id: id } });
//   }

//   public postProgrammer(p: Programmer) {
//     return this.http.post<boolean>(this.endpoint + '/postProgrammer', p);
//   }

//   public putProgrammer(p: Programmer) {
//     return this.http.put<boolean>(this.endpoint + '/putProgrammer', p);
//   }
}
