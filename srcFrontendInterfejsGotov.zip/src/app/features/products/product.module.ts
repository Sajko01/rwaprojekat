import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; // Dodaj ovo
import { ProductsComponent } from './components/products.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ProductsComponent,
  ],
  imports: [
    CommonModule, // Dodaj ovo
    HttpClientModule,
    FormsModule,
  ],
  exports: [
    ProductsComponent,
  ]
})
export class ProductsModule { }