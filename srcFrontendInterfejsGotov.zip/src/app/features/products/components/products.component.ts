import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Product } from '../interfaces/product';
import { selectIsLoggedIn, selectUserNick } from '../../../auth/auth.selectors';
import { AuthState } from '../../../auth/auth.state';
import { Store } from '@ngrx/store';
import { BehaviorSubject, catchError, map, Observable, of, switchMap } from 'rxjs';
import { CartService } from '../../cart/services/cart.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-products',
  //standalone: true,
 // imports: [],
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss'
})
export class ProductsComponent {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  selectedType: string = '';
  searchTerm: string = '';
  cartId=0;
  isInCart: boolean = false; 
  productsInCart: { [key: number]: boolean } = {}; // Praćenje proizvoda u korpi

  //isInCart$ = new BehaviorSubject<boolean>(false);


  isLoggedIn$: Observable<boolean>;
  userNick$: Observable<string | undefined>; // Posmatraj nadimak korisnika

  constructor(private store: Store<AuthState>,private http: HttpClient,private cartService:CartService,private router: Router) {
    this.isLoggedIn$ = this.store.select(selectIsLoggedIn);
    this.userNick$ = this.store.select(selectUserNick); // Selektuj nadimak
  }

 // constructor() {}

  ngOnInit(): void {
    this.loadProducts();
    //this.checkProductInCartForUser(this.productId);
  }
  cartItems: { product: any, quantity: number }[] = [];





  

  checkProductInCart(productId: number) {
    this.userNick$
      .pipe(
        switchMap((email) => {
          if (email) {
            return this.cartService.getCartForUser(email); // Ovo treba da vraća Observable cartId
          } else {
            return of(null);
          }
        }),
        switchMap((cartId) => {
          if (cartId) {
            return this.cartService.isProductInCart(cartId, productId); // Proveravamo da li je proizvod u korpi
          } else {
            return of(false); // Ako nema cartId, vraćamo false
          }
        })
      )
      .subscribe({
        next: (exists) => {
          this.productsInCart[productId] = exists; // Postavljamo stanje za određeni proizvod
        },
        error: (err) => {
          console.error('Greška prilikom provere:', err);
        },
      });
  }





  deleteCartItems( productId: number) {

    this.userNick$
      .pipe(
        // Kada dobiješ email, koristi ga da dobiješ ID korpe
        switchMap((email) => {
          if (email) {
            return this.cartService.getCartForUser(email); // Pozivamo servis da dobijemo Cart ID na osnovu email-a
          } else {
            return of(null); // Ako nema email-a, vraćamo prazan Observable
          }
        })
      )
      .subscribe({
        next: (cartId) => {
          if (cartId) {
            this.cartId = cartId;  // Postavi cartId ako je pronađena korpa
            this.cartService.deleteCartItemsByCartAndProductId(this.cartId, productId).subscribe({
              next: (response) => {
                console.log('Uspešno obrisano:', response);
              },
              error: (err) => {
                console.error('Greška prilikom brisanja:', err);
              },
            });
          } 
        },
        error: (error) => {
          console.error('Greška prilikom brisanja stavke:', error);
          this.cartId = 0;  // U slučaju greške postavi cartId na 0
        }
      });
  

      this.checkProductInCart(productId);


       
    
  }

 


  addToCart(product: any) {
    this.userNick$.subscribe((email) => {
      if (email) {
        const quantityToAdd = product.quantityToAdd || 1; // Ako korisnik nije dodao količinu, podesi na 1
        this.cartService.getCartForUser(email).subscribe((cartId: number) => {
          const cartItem = {
            cartId: cartId,
            productId: product.id,
            quantity: quantityToAdd,
          };

          this.cartService.createCartItem(cartItem).subscribe(
            (response) => {
              console.log('Proizvod uspešno dodat u korpu', response);
            },
            (error) => {
              console.error('Greška prilikom dodavanja proizvoda u korpu',cartId,product.id,quantityToAdd," "+ error);
            }
          );
        });
      }
    });
    this.checkProductInCart(product.id);
  }






  removeFromCart(product: any) {
    this.cartItems = this.cartItems.filter(item => item.product.id !== product.id);
  }

  // isInCart(product: any): boolean {
  //   return this.cartItems.some(item => item.product.id === product.id);
  // }
  
  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  scrollToProducts() {
    const element = document.getElementById('products-section');
    if (element) {
      const yOffset = -70; // Offset od -50px
      const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: yPosition, behavior: 'smooth' });
    }
  }

  scrollToUsers() {
    // Prebaci se na stranicu sa proizvodima
    this.router.navigate(['/user']).then(() => {
      // Nakon navigacije, koristi setTimeout kako bi sačekao da se stranica učita
      setTimeout(() => {
        const element = document.getElementById('user-section');
        if (element) {
          const yOffset = 0; // Offset od 70px
          const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
          window.scrollTo({ top: yPosition, behavior: 'smooth' });
        }
      }, 200); // Sačekaj 0 milisekundi, ali dovoljno da se DOM učita
    });
  }
  
  

  getImageUrl(imagePath: string): string {
    return `http://localhost:3000/img/${imagePath}`;
  }

  // loadProducts(): void {
  //   this.http.get<Product[]>('http://localhost:3000/product')
  //     .subscribe(data => {
  //       this.products = data;
  //       this.filteredProducts = data; // Inicijalizuj filteredProducts sa učitanim proizvodima
  //     });
  // }

  loadProducts(): void {
    this.http.get<Product[]>('http://localhost:3000/product')
      .subscribe(data => {
        this.products = data.map(product => ({
          ...product,
          quantityToAdd: 1 // Inicijalizuj quantityToAdd na 1
          
        }));
        this.filteredProducts = this.products; // Inicijalizuj filteredProducts sa učitanim proizvodima

        this.products.forEach(product => {
          this.checkProductInCart(product.id); // Pozivamo metodu za proveru
        });
        
      });

      
  }


















  get uniqueTypes() {
    return Array.from(new Set(this.products.map(product => product.type)));
  }

  filterProducts() {
    this.filteredProducts = this.products.filter(product =>
      (this.selectedType ? product.type === this.selectedType : true) &&
      (this.searchTerm ? product.name.toLowerCase().includes(this.searchTerm.toLowerCase()) : true)
    );
  
    
  }}