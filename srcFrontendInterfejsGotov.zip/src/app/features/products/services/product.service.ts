import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Product } from '../interfaces/product';

@Injectable({
  providedIn: 'root',
})
export class ProgrammerService {
  private endpoint = 'http://localhost:3000/product';
  constructor(private http: HttpClient) { }

  public getProducts() {
    return this.http.get<Product[]>(this.endpoint);
  }

  public getProduct(id: number) {
    return this.http.get<Product>(this.endpoint, { params: { id: id } });
  }

//   public getProductsMax(id: number) {
//     return this.http.get<Product>(this.endpoint, { params: { id: id } });
//   }

  public postProduct(p: Product) {
    return this.http.post<boolean>(this.endpoint, p);
  }

  public putProduct(p: Product) {
    return this.http.put<boolean>(this.endpoint, p);
  }

  //delete
}
