import { Component,} from '@angular/core';


@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss'
})




export class FooterComponent {
  //@Input()
  //appName: string = ""
 // @Input()
  //links: { label: string, route: string,requiresAuth:boolean }[] = [];
  
  //isLoggedIn$: Observable<boolean>;
  //userNick$: Observable<string | undefined>; // Posmatraj nadimak korisnika

  constructor() {
           // this.isLoggedIn$ = this.store.select(selectIsLoggedIn);
              // this.userNick$ = this.store.select(selectUserNick); // Selektuj nadimak
  }

  //logout() {
 //  this.store.dispatch(logout());
  //}

//   scrollToTop() {
//     window.scrollTo({ top: 0, behavior: 'smooth' });
//   }
  
}
