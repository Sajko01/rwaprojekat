import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { HeaderComponent } from './components/header/header.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
//import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDialogModule } from '@angular/material/dialog';
//import { NewProjectDialogComponent } from './components/new-project-dialog/new-project-dialog.component';
//import { NewProgrammerDialogComponent } from './components/new-programmer-dialog/new-programmer-dialog.component';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './components/header/header.component';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './components/footer/footer.component';
//import { ProjectsModule } from '../features/projects/projects.module';
//import { ProgrammerModule } from '../features/programmers/programmer.module';
//import { HomeComponent } from '../home/home.component';


@NgModule({
  //declarations: [HeaderComponent, NewProjectDialogComponent, NewProgrammerDialogComponent],
  declarations: [HeaderComponent,FooterComponent],
  imports: [
    CommonModule,
    RouterModule,
    MatIconModule,
    MatButtonModule,
    MatToolbarModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatDialogModule,
    MatSelectModule,
  ],
  //exports: [HeaderComponent, NewProjectDialogComponent, NewProgrammerDialogComponent]
  exports: [HeaderComponent,FooterComponent]
})
export class CoreModule { }