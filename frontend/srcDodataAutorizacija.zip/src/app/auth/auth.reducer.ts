// auth.reducer.ts
import { createReducer, on } from '@ngrx/store';
import * as AuthActions from './auth.actions';
import { initialState, AuthState } from './auth.state';

export const authReducer = createReducer(
  initialState,
  on(AuthActions.login, (state, { nick,role,token }) => {
    localStorage.setItem('authToken', token); // Čuvanje tokena u localStorage
    return { ...state, isLoggedIn: true, nick, role, token };
  }),
    // ({ ...state, isLoggedIn: true, nick ,role,token})), // Dodaj nick u state
  on(AuthActions.logout, (state) => {
    localStorage.removeItem('authToken'); // Brisanje tokena iz localStorage prilikom odjave
    return { ...state, isLoggedIn: false, nick: '', role: undefined, token: undefined };
  })
    // ({ ...state, isLoggedIn: false, nick: '',role:undefined , token: undefined})) // Poništi nick prilikom logout-a
);


//localStorage.removeItem('authToken'); cak kaze ovo unutar akcije