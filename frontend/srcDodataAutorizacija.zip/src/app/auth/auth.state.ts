export interface AuthState {
    isLoggedIn: boolean;
    nick?: string; // Dodaj nadimak kao opcionalno polje
    role?:string;
    token?: string;
  }
  
  export const initialState: AuthState = {
    isLoggedIn: false,
    role: undefined,
    token: undefined,
  };