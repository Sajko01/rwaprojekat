// import { Routes } from '@angular/router';

// export const routes: Routes = [];



import { Routes } from '@angular/router';
import { ProductsComponent } from './features/products/components/products.component';
import { ServicesComponent } from './features/services/components/services.component';
import { CartComponent } from './features/cart/components/cart.component';
import { OrdersComponent } from './features/orders/components/orders.component';
import { UserComponent } from './features/user/components/user.component';
// import { ProductsComponent } from './products/products.component';
// import { ServicesComponent } from './services/services.component';
// import { CartComponent } from './cart/cart.component';
// import { OrdersComponent } from './orders/orders.component';
// import { UserComponent } from './user/user.component';

export const routes: Routes = [
  { path: 'products', component: ProductsComponent },
  { path: 'services', component: ServicesComponent },
  { path: 'cart', component: CartComponent },
  { path: 'orders', component: OrdersComponent},
  { path: 'user', component: UserComponent },
  { path: '', redirectTo: '/products', pathMatch: 'full' }
];