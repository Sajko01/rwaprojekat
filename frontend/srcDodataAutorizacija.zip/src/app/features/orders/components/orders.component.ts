import { Component, Input } from '@angular/core';
import { OrderService } from '../services/order.service';
import { CartService } from '../../cart/services/cart.service';
import { catchError, combineLatest, interval, map, Observable, of, Subscription, switchMap, tap } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { AuthState } from '../../../auth/auth.state';
import { Store } from '@ngrx/store';
import { selectIsLoggedIn, selectUserNick, selectUserRole } from '../../../auth/auth.selectors';
import { CreateOrderDto, OrderDto, OrderWithDelete } from '../interfaces/order';

@Component({
  selector: 'app-orders',
  //standalone: true,
  //imports: [],
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.scss'
})
export class OrdersComponent {

  //@Input() orderDate!: Date;
 // @Input() orderId!: number;

  //canDelete: boolean = false;
  //deleteMessage: string = '';




  cartId: number | null = null;
  userEmail: string = '';
  totalPrice: number | null = null;
  dis:boolean=false;
 // orders$: Observable<OrderDto[]> | null=null;
// orders$: Observable<OrderWithDelete[]>;
orders$: Observable<OrderWithDelete[]> = of([]); // Prazan observable
ordersAdmin$: Observable<OrderDto[]> = of([]);



//Nek seinicijalizuje ako je admin samo!!!!OBAVEZNO STAVI TAKO A NE OVDE ODMA




// ordersAdmin$: Observable<OrderDto[]> = this.orderService.getAllOrdersForAdmin().pipe(
//   // Ispis tokena iz localStorage pre slanja zahteva
//   tap(() => {
//     const token = localStorage.getItem('authToken');
//     console.log('Token iz localStorage:'+this.userRole$, token);
    
//   }),
//   // Hvatanje grešaka i ispis u konzoli
//   catchError((error) => {
//     console.error('Greška prilikom dohvatanja narudžbina:', error);
//     return of([]); // Vraćamo prazan niz kako bismo sprečili crash aplikacije
//   })
// );
OrderAdmin(){
this.ordersAdmin$ = combineLatest([this.userRole$]).pipe(
  switchMap(([role]) => {
    // Proveri da li je korisnička uloga "admin"
    if (role === 'admin') {
      return this.orderService.getAllOrdersForAdmin().pipe(
        // Ispis tokena iz localStorage pre slanja zahteva
        tap(() => {
          const token = localStorage.getItem('authToken');
          console.log('Token iz localStorage:', token);
        }),
        // Hvatanje grešaka i ispis u konzoli
        catchError((error) => {
          console.error('Greška prilikom dohvatanja narudžbina:', error);
          return of([]); // Vraćamo prazan niz kako bismo sprečili crash aplikacije
        })
      );
    } else {
      // Ako nije admin, vrati prazan niz
      return of([]);
    }
  })
);
}
private intervalSubscription!: Subscription;
  cartIsEmpty$: Observable<boolean>| null = null; 
 

ngOnInit() {
  this.cartIsEmpty$ = this.checkIfCartIsEmpty();
 this.loadOrders();
 this.userRole$.subscribe(role => {
  if (role === 'admin') {
    this.OrderAdmin(); // Poziv tvoje funkcije
  }
});
 //this.canDeleteOrder();
//  this.intervalSubscription = interval(10000).subscribe(() => {
//   this.checkOrdersStatus();
// });


//cINI MI SE DA OVO OSVEZAVANJE OPSTE NE TREBA?

this.intervalSubscription = interval(60000).pipe(
  switchMap(() => this.orderService.getOrdersByUserEmail(this.userEmail))
).subscribe(orders => {
  this.checkOrdersStatus(); // Osveži samo dugme
});
}
ngOnDestroy(): void {
  // Prekini interval kada se komponenta uništi
  if (this.intervalSubscription) {
    this.intervalSubscription.unsubscribe();
  }
}


// loadOrders(): void {
//   // Pretpostavljamo da userNick$ već postoji u nekom servisu (npr. UserService)
//  // this.userNick$ = this.userService.getUserNick(); // Dobijaš observable userNick$

//   this.orders$ = this.userNick$.pipe(
//     // Kada dobiješ email korisnika (userNick$ predstavlja email u ovom slučaju)
//     switchMap((email) => {
//       if (email) {
//         this.userEmail = email; // Sačuvaj email korisnika
//         // Pozovi servis za narudžbine i vrati Observable narudžbina na osnovu email-a
//         //console.log(this.userEmail)
//         return this.orderService.getOrdersByUserEmail(this.userEmail).pipe(
//           map(orders => 
//             orders.map(order => ({
//               ...order, // kopiramo sve postojeće podatke narudžbine
//               canDelete: this.canDeleteOrder(order.orderDate) // dodajemo novo svojstvo `canDelete`
//             }))
//           )
//         );
//       } else {
//         return of([]); // Ako nema email-a, vraćamo prazan niz narudžbina
//       }
//     })
//   );
// }
loadOrders(): void {
  this.orders$ = this.userNick$.pipe(
    switchMap((email) => {
      if (email) {
        this.userEmail = email;
        return this.orderService.getOrdersByUserEmail(this.userEmail).pipe(
          map(orders => 
            orders.map(order => ({
              ...order,
              canDelete: this.canDeleteOrder(order.orderDate)
            }))
          )
        );
      } else {
        return of([]); // Ako nema email-a, vraćamo prazan niz narudžbina
      }
    }),
    map(orders => orders || []) // Osiguraj da nije undefined
  );
}


   
//  checkIfCanDelete(): void {
//     const now = new Date();
//     const fiveMinutes = 5 * 60 * 1000; // 5 minuta u milisekundama
//     const timeDifference = now.getTime() - new Date(this.orderDate).getTime();

//     this.canDelete = timeDifference <= fiveMinutes;
//     if (!this.canDelete) {
//       this.deleteMessage = 'Order can no longer be deleted.';
//     }
//   }

//   deleteOrder(): void {
//     if (this.canDelete) {
//       this.orderService.deleteOrderById(this.orderId).subscribe(
//         () => {
//           console.log('Order deleted successfully');
//           // Možda želiš da osvežiš listu porudžbina nakon brisanja
//         },
//         (error) => {
//           console.error('Error deleting order', error);
//         }
//       );
//     }
//   }
canDeleteOrder(orderDate: Date): boolean {
  const now = new Date();
  const fiveMinutes =5 * 60 * 1000; // 5 minuta u milisekundama// 5 * 60 * 1000;
  const orderTime = new Date(orderDate).getTime();
  return now.getTime() - orderTime <= fiveMinutes;
}
// updateCanDelete(orders: OrderWithDelete[]): void {
//   const currentTime = new Date().getTime();
//   this.orders$ = orders.map(order => ({
//     ...order,
//     canDelete: (currentTime - new Date(order.orderDate).getTime()) < 5 * 60 * 1000 // 5 minuta
//   }));
// }
deleteOrder(orderId: number): void {
  this.orderService.deleteOrderById(orderId).subscribe(
    () => {
      console.log('Order deleted successfully');
      // Ovdje možeš osvežiti listu narudžbina nakon brisanja
      this.loadOrders(); // Osvežavanje liste narudžbina
    },
    (error) => {
      console.error('Error deleting order', error);
    }
  );
}

checkOrdersStatus(): void {
  // Ponovno učitavanje narudžbina kako bi se ažuriralo `canDelete` svojstvo
  this.orders$ = this.orders$?.pipe(
    map(orders =>
      orders.map(order => ({
        ...order, 
        canDelete: this.canDeleteOrder(order.orderDate)
      }))
    )
  );
}
  
  
  
 
  isLoggedIn$: Observable<boolean>;
  userNick$: Observable<string | undefined>; // Posmatraj nadimak korisnika
  userRole$: Observable<string | undefined>; 


  constructor( private orderService: OrderService,private store: Store<AuthState>,private http: HttpClient,private cartService:CartService) {
    this.isLoggedIn$ = this.store.select(selectIsLoggedIn);
    this.userNick$ = this.store.select(selectUserNick); // Selektuj nadimak
    this.userRole$ = this.store.select(selectUserRole); 
  }


  //Ovde ne treba vec u KORPI!!!
  submitOrder() {
    // Pretpostavljamo da userNick$ već postoji i daje email korisnika
    this.userNick$
      .pipe(
        // Kada dobiješ email, koristi ga da dobiješ ID korpe
        switchMap((email) => {
          if (email) {
            this.userEmail =email ;
            return this.cartService.getCartForUser(email); // Pozivamo servis da dobijemo Cart ID na osnovu email-a
          } else {
            return of(null); // Ako nema email-a, vraćamo prazan Observable
          }
        })
      )
      .subscribe({
        next: (cartId) => {
          if (cartId) {
            this.cartId = cartId;  // Postavi ID korpe
             // Pretpostavljamo da u Cart objektu imaš i userId
            this.totalPrice = 0; // Preuzmi ukupnu cenu iz korpe ako je dostupna
            
            // Kreiraj DTO za narudžbinu
            const orderDto: CreateOrderDto = {
              id: 0, // Automatski generisano
              userEmail: this.userEmail,
              cartId: this.cartId,
              totalPrice: this.totalPrice || 0, // Ako nije definisana, postavi na 0
              orderDate: new Date(),
            };

            // Pozovi servis da kreira narudžbinu
            this.orderService.createOrder(orderDto).subscribe({
              next: (response) => {
                if (this.cartId !== null) { // Proveri da li je cartId validan
                  this.cartService.deleteCartItemsByCartId(this.cartId).subscribe({
                    next: () => {
                      console.log('Cart items successfully deleted and order maked');
                    },
                    error: (error) => {
                      console.error('Error deleting cart items', error);
                    }
                  });
                } else {
                  console.error('Cart ID is null, cannot delete items');
                }
              },
              error: (error) => {
                console.error('Error creating order', error);
              }
            });
          }
        },
        error: (error) => {
          console.error('Error fetching cart', error);
        }
      });
  }




  checkIfCartIsEmpty(): Observable<boolean> {
    return this.userNick$.pipe(
      switchMap((email) => {
        if (email) {
          return this.cartService.getCartForUser(email); // Dobijamo Cart ID na osnovu email-a
        } else {
          return of(null); // Ako nema email-a, vraćamo prazan Observable
        }
      }),
      switchMap((cartId) => {
        console.log(cartId); // Ispisujemo cartId za debagovanje
        if (cartId) {
          // Pozivamo backend servis da proverimo da li je korpa prazna
          return this.cartService.isCartEmpty(cartId).pipe(
            tap(response => console.log('Response from isCartEmpty:', response)), 
            map(response => response.isEmpty) // Vraćamo samo boolean vrednost
          );
        } else {
          return of(true); // Ako nema cartId, vraćamo true kao da je prazna
        }
      })
    );
  }





  getImageUrl(imagePath: string): string {
    return `http://localhost:3000/img/${imagePath}`;
  }

}
