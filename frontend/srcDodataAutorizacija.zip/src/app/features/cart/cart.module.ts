import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; // Dodaj ovo
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CartComponent } from './components/cart.component';


@NgModule({
  declarations: [
    CartComponent,
  ],
  imports: [
    CommonModule, // Dodaj ovo
    HttpClientModule,
    FormsModule,
  ],
  exports: [
    CartComponent,
  ]
})
export class CartModule { }