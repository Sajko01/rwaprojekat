// import { createSelector } from '@ngrx/store';
// import { CartState } from './cart.reducer';

// export const selectCart = (state: AppState) => state.cart;

// export const selectCartItems = createSelector(
//   selectCart,
//   (cartState: CartState) => cartState.items
// );

// export const selectTotalPrice = createSelector(
//   selectCartItems,
//   (items: CartItem[]) =>
//     items.reduce((total, item) => total + (item.product?.price || item.service?.price) * item.quantity, 0)
// );
