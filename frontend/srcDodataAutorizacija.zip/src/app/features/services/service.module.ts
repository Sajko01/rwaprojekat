import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; // Dodaj ovo
import { ServicesComponent } from './components/services.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ServicesComponent,
  ],
  imports: [
    CommonModule, // Dodaj ovo
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [
   ServicesComponent,
  ]
})
export class ServicesModule { }