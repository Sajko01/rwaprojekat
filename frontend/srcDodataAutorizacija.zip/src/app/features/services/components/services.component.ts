import { Component } from '@angular/core';
import { Service } from '../interfaces/service';
import { HttpClient } from '@angular/common/http';
import { Observable, of, switchMap } from 'rxjs';
import { Store } from '@ngrx/store';
import { AuthState } from '../../../auth/auth.state';
import { selectIsLoggedIn, selectUserNick, selectUserRole } from '../../../auth/auth.selectors';
import { CartService } from '../../cart/services/cart.service';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ServiceDialogComponent } from '../dialog/service-dialog.component';
import { ServiceService } from '../services/service.service';
import { DialogComponent } from '../../products/dialog/confirm-dialog.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-services',
  //standalone: true,
  //imports: [],
  templateUrl: './services.component.html',
  styleUrl: './services.component.scss'
})
export class ServicesComponent {
 services:Service[]=[];
 cartId=0;
 servicesInCart: { [key: number]: boolean } = {};

 isLoggedIn$: Observable<boolean>;
 userNick$: Observable<string | undefined>; // Posmatraj nadimak korisnika
 userRole$: Observable<string | undefined>; 

 serviceForm: FormGroup;
 selectedImage: File | null = null;

 

 isHovering = false;

 constructor(private store: Store<AuthState>,
  private http: HttpClient,
  private cartService:CartService,
  private serviceService:ServiceService,
  private router: Router,
  private dialog:MatDialog,
  private fb: FormBuilder,) {
   this.isLoggedIn$ = this.store.select(selectIsLoggedIn);
   this.userNick$ = this.store.select(selectUserNick); // Selektuj nadimak
   this.userRole$ = this.store.select(selectUserRole);

   this.serviceForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(1)]],
    pricePerUnit: ['', [Validators.required, Validators.min(0)]],
    description: ['', [Validators.required]],
    image: [null, Validators.required],
  });
 }


 openServiceDialog(serviceDescription: string,serviceName:string): void {
  const dialogRef = this.dialog.open(ServiceDialogComponent, {
    data: { description: serviceDescription ,
            name:serviceName
    },
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('Dijalog zatvoren');
  });
}

 

 //constructor(private http: HttpClient) {}

 cartItems: { service: Service, quantity: number }[] = [];



 checkServiceInCart(serviceId: number) {
  this.userNick$
    .pipe(
      switchMap((email) => {
        if (email) {
          return this.cartService.getCartForUser(email); // Ovo treba da vraća Observable cartId
        } else {
          return of(null);
        }
      }),
      switchMap((cartId) => {
        if (cartId) {
          return this.cartService.isServiceInCart(cartId, serviceId); // Proveravamo da li je proizvod u korpi
        } else {
          return of(false); // Ako nema cartId, vraćamo false
        }
      })
    )
    .subscribe({
      next: (exists) => {
        this.servicesInCart[serviceId] = exists; // Postavljamo stanje za određeni proizvod
      },
      error: (err) => {
        console.error('Greška prilikom provere:', err);
      },
    });
}

deleteCartItems( serviceId: number) {

  this.userNick$
    .pipe(
      // Kada dobiješ email, koristi ga da dobiješ ID korpe
      switchMap((email) => {
        if (email) {
          return this.cartService.getCartForUser(email); // Pozivamo servis da dobijemo Cart ID na osnovu email-a
        } else {
          return of(null); // Ako nema email-a, vraćamo prazan Observable
        }
      })
    )
    .subscribe({
      next: (cartId) => {
        if (cartId) {
          this.cartId = cartId;  // Postavi cartId ako je pronađena korpa
          this.cartService.deleteCartItemsByCartAndServiceId(this.cartId, serviceId).subscribe({
            next: (response) => {
              console.log('Uspešno obrisano:', response);
            },
            error: (err) => {
              console.error('Greška prilikom brisanja:', err);
            },
          });
        } 
      },
      error: (error) => {
        console.error('Greška prilikom brisanja stavke:', error);
        this.cartId = 0;  // U slučaju greške postavi cartId na 0
      }
    });


    this.checkServiceInCart(serviceId);


     
  
}

scrollToUsers() {
  // Prebaci se na stranicu sa proizvodima
  this.router.navigate(['/user']).then(() => {
    // Nakon navigacije, koristi setTimeout kako bi sačekao da se stranica učita
    setTimeout(() => {
      const element = document.getElementById('user-section');
      if (element) {
        const yOffset = 0; // Offset od 70px
        const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
        window.scrollTo({ top: yPosition, behavior: 'smooth' });
      }
    }, 200); // Sačekaj 0 milisekundi, ali dovoljno da se DOM učita
  });
}


addToCart(service: any) {
  this.userNick$.subscribe((email) => {
    if (email) {
      const quantityToAdd = service.quantityToAdd || 1; // Ako korisnik nije dodao količinu, podesi na 1
      this.cartService.getCartForUser(email).subscribe((cartId: number) => {
        const cartItem = {
          cartId: cartId,
          serviceId: service.id,
          quantity: quantityToAdd,
        };

        this.cartService.createCartItem(cartItem).subscribe(
          (response) => {
            console.log('Usluga uspešno dodata u korpu', response);
          },
          (error) => {
            console.error('Greška prilikom dodavanja usluge u korpu',cartId,service.id,quantityToAdd," "+ error);
          }
        );
      });
    }
  });
  this.checkServiceInCart(service.id);
}

 

  removeFromCart(service: Service) {
    this.cartItems = this.cartItems.filter(item => item.service.id !== service.id);
  }

  isInCart(service: Service): boolean {
    return this.cartItems.some(item => item.service.id === service.id);
  }

 

//  scrollToServices() {
//   const servicesSection = document.getElementById('services-section');
//   if (servicesSection) {
//     servicesSection.scrollIntoView({ behavior: 'smooth' });
//   }}

  scrollToServices() {
    const element = document.getElementById('services-section');
    if (element) {
      const yOffset = -70; // Offset od -50px
      const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: yPosition, behavior: 'smooth' });
    }
  }



  images: string[] = [
    '/assets/dvorista4.png',
    '/assets/dvorista5.png',
    '/assets/dvorista6.png'
  ];
  currentImage: string="";
  currentIndex: number = 0;

  ngOnInit() {
    this.loadServices();


    //za naslovne slicice
    this.currentImage = this.images[this.currentIndex];
    setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.images.length;
      this.currentImage = this.images[this.currentIndex];
    }, 5000); // Menja sliku svake 5 sekundi
  }

  // ngOnInit(): void {
  //   this.loadProducts();
  // }
  //cartItems: { product: any, quantity: number }[] = [];
  
 

  
  
  

  getImageUrl(imagePath: string): string {
    return `http://localhost:3000/img/${imagePath}`;
  }

  loadServices(): void {
    this.http.get<Service[]>('http://localhost:3000/service')
      .subscribe(data => {
        this.services = data.map(service=> ({
        ...service,
        quantityToAdd:1,
        newPrice:1,

        }));
       
        this.services.forEach(service => {
          this.checkServiceInCart(service.id); // Pozivamo metodu za proveru
        });
       
        //this.filteredProducts = data; // Inicijalizuj filteredProducts sa učitanim proizvodima
      });
  }


  updatePrice(serviceId: number, newPrice: number | undefined) {
    if(newPrice!=undefined)
    this.serviceService.updateServicePrice(serviceId, newPrice)
      .subscribe({
        next: (result: any) => {
          console.log('Cena uspešno ažurirana:', result);
          this.loadServices();
        },
        error: (error) => {
          console.error('Greška prilikom ažuriranja cene:'+serviceId+"DA"+newPrice, error);
        },
      });
  }

//koristi iz product confirm dialog, DialogComponent
  openConfirmDialog(serviceId:number): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: { name: 'Potvrda brisanja', description: 'Da li ste sigurni da želite da obrišete ovu uslugu?' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteService(serviceId);
      }
    });
  }


  deleteService(id: number): void {
    this.serviceService.deleteService(id).subscribe({
      next: (response) => {
        console.log('Usluga obrisana:', response);
        this.loadServices();
        // Ovdje možeš dodati kod za obaveštavanje korisnika ili osvežavanje liste usluga
      },
      error: (error) => {
        console.error('Greška prilikom brisanja usluge:', error);
      }
    });
  }


  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
      this.selectedImage = file;
      this.serviceForm.patchValue({ image: file });
      this.serviceForm.get('image')?.updateValueAndValidity();
    } else {
      console.error('Pogrešan format fajla, očekuje se slika.');
      this.serviceForm.patchValue({ image: null });
    }

    console.log('Selected Image:', this.selectedImage);
  }

  onSubmit(): void {
    if (this.serviceForm.valid && this.selectedImage) {
      const createServiceDto: Service = {
        id: 0, // Generiše se na backendu
        name: this.serviceForm.value.name,
        pricePerUnit: this.serviceForm.value.pricePerUnit,
        description: this.serviceForm.value.description,
        image: '',
      };

      this.serviceService.createService(createServiceDto, this.selectedImage)
        .subscribe({
          next: (service) => {
            console.log('Service created successfully:', service);
            this.loadServices();
          },
          error: (error) => {
            console.error('Error creating service:', error);
          },
        });
    } else {
      console.log('Forma nije validna');
    }
  }

}


  

 
  