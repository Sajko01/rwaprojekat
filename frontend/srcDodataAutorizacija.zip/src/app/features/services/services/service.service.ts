import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Service } from '../interfaces/service';


@Injectable({
  providedIn: 'root',
})
export class ServiceService {
  private endpoint = 'http://localhost:3000/service';
  constructor(private http: HttpClient) { }


  updateServicePrice(id: number, pricePerUnit: number): Observable<any> {
    const token = localStorage.getItem('authToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.put<any>(`${this.endpoint}/${id}/price`, { pricePerUnit},{headers});
  }

  deleteService(id: number): Observable<any> {
    const token = localStorage.getItem('authToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.delete<any>(`${this.endpoint}/${id}`, { headers });
  }

//   public getProgrammers() {
//     return this.http.get<Programmer[]>(this.endpoint + '/getProgrammers');
//   }

//   public getProgrammer(id: number) {
//     return this.http.get<Programmer>(this.endpoint, { params: { id: id } });
//   }

//   public postProgrammer(p: Programmer) {
//     return this.http.post<boolean>(this.endpoint + '/postProgrammer', p);
//   }

//   public putProgrammer(p: Programmer) {
//     return this.http.put<boolean>(this.endpoint + '/putProgrammer', p);
//   }


createService(serviceData: Service, image: File): Observable<Service> {
  const formData = new FormData();
  formData.append('name', serviceData.name);
  formData.append('pricePerUnit', serviceData.pricePerUnit.toString());
  formData.append('description', serviceData.description);
  formData.append('image', image); // Ovde šalješ celokupni fajl

  const token = localStorage.getItem('authToken'); // Uzimanje tokena iz localStorage
  const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

  return this.http.post<Service>(this.endpoint, formData, { headers });
}
}
