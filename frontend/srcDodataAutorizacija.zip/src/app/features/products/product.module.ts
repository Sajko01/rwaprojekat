import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; // Dodaj ovo
import { ProductsComponent } from './components/products.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogComponent } from './dialog/confirm-dialog.component';
import { MatDialogActions } from '@angular/material/dialog';


@NgModule({
  declarations: [
    ProductsComponent,
  ],
  imports: [
    CommonModule, // Dodaj ovo
    HttpClientModule,
    FormsModule,
    //DeleteProductComponent,
    //ConfirmDialogComponent,
    MatDialogActions,
    ReactiveFormsModule,
    
  ],
  exports: [
    ProductsComponent,
  ]
})
export class ProductsModule { }