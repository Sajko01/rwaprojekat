import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Product } from '../interfaces/product';
import { selectIsLoggedIn, selectUserNick, selectUserRole } from '../../../auth/auth.selectors';
import { AuthState } from '../../../auth/auth.state';
import { Store } from '@ngrx/store';
import { BehaviorSubject, catchError, map, Observable, of, switchMap } from 'rxjs';
import { CartService } from '../../cart/services/cart.service';
import { Router } from '@angular/router';
import { ProductService } from '../services/product.service';
import { DialogComponent } from '../dialog/confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-products',
  //standalone: true,
 // imports: [],
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss'
})
export class ProductsComponent {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  selectedType: string = '';
  searchTerm: string = '';
  cartId=0;
  isInCart: boolean = false; 
  productsInCart: { [key: number]: boolean } = {}; // Praćenje proizvoda u korpi

  //isInCart$ = new BehaviorSubject<boolean>(false);


  isLoggedIn$: Observable<boolean>;
  userNick$: Observable<string | undefined>; // Posmatraj nadimak korisnika
  userRole$: Observable<string | undefined>; 

 // Selektuj nadimak
 productForm: FormGroup;
  selectedImage: File | null = null;
   

  constructor(private store: Store<AuthState>,
    private http: HttpClient,
    private cartService:CartService,
    private router: Router,
    private productService: ProductService,
    private dialog: MatDialog,
    private fb: FormBuilder) {
    this.isLoggedIn$ = this.store.select(selectIsLoggedIn);
    this.userNick$ = this.store.select(selectUserNick); // Selektuj nadimak
    this.userRole$ = this.store.select(selectUserRole);

    this.productForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(1)]],
      type: ['', [Validators.required, Validators.minLength(1)]],
      price: ['', [Validators.required, Validators.min(0)]],
      quantity: ['', [Validators.required, Validators.min(1), Validators.pattern(/^\d+$/)]],
      image: ['', Validators.required],
    });
  }

 // constructor() {}

  ngOnInit(): void {
    this.loadProducts();
    //this.checkProductInCartForUser(this.productId);
  }
  cartItems: { product: any, quantity: number }[] = [];





  

  checkProductInCart(productId: number) {
    this.userNick$
      .pipe(
        switchMap((email) => {
          if (email) {
            return this.cartService.getCartForUser(email); // Ovo treba da vraća Observable cartId
          } else {
            return of(null);
          }
        }),
        switchMap((cartId) => {
          if (cartId) {
            return this.cartService.isProductInCart(cartId, productId); // Proveravamo da li je proizvod u korpi
          } else {
            return of(false); // Ako nema cartId, vraćamo false
          }
        })
      )
      .subscribe({
        next: (exists) => {
          this.productsInCart[productId] = exists; // Postavljamo stanje za određeni proizvod
        },
        error: (err) => {
          console.error('Greška prilikom provere:', err);
        },
      });
  }





  deleteCartItems( productId: number) {

    this.userNick$
      .pipe(
        // Kada dobiješ email, koristi ga da dobiješ ID korpe
        switchMap((email) => {
          if (email) {
            return this.cartService.getCartForUser(email); // Pozivamo servis da dobijemo Cart ID na osnovu email-a
          } else {
            return of(null); // Ako nema email-a, vraćamo prazan Observable
          }
        })
      )
      .subscribe({
        next: (cartId) => {
          if (cartId) {
            this.cartId = cartId;  // Postavi cartId ako je pronađena korpa
            this.cartService.deleteCartItemsByCartAndProductId(this.cartId, productId).subscribe({
              next: (response) => {
                console.log('Uspešno obrisano:', response);
              },
              error: (err) => {
                console.error('Greška prilikom brisanja:', err);
              },
            });
          } 
        },
        error: (error) => {
          console.error('Greška prilikom brisanja stavke:', error);
          this.cartId = 0;  // U slučaju greške postavi cartId na 0
        }
      });
  

      this.checkProductInCart(productId);


       
    
  }

 


  addToCart(product: any) {
    this.userNick$.subscribe((email) => {
      if (email) {
        const quantityToAdd = product.quantityToAdd || 1; // Ako korisnik nije dodao količinu, podesi na 1
        this.cartService.getCartForUser(email).subscribe((cartId: number) => {
          const cartItem = {
            cartId: cartId,
            productId: product.id,
            quantity: quantityToAdd,
          };

          this.cartService.createCartItem(cartItem).subscribe(
            (response) => {
              console.log('Proizvod uspešno dodat u korpu', response);
            },
            (error) => {
              console.error('Greška prilikom dodavanja proizvoda u korpu',cartId,product.id,quantityToAdd," "+ error);
            }
          );
        });
      }
    });
    this.checkProductInCart(product.id);
  }






  removeFromCart(product: any) {
    this.cartItems = this.cartItems.filter(item => item.product.id !== product.id);
  }

  // isInCart(product: any): boolean {
  //   return this.cartItems.some(item => item.product.id === product.id);
  // }
  
  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  scrollToProducts() {
    const element = document.getElementById('products-section');
    if (element) {
      const yOffset = -70; // Offset od -50px
      const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: yPosition, behavior: 'smooth' });
    }
  }

  scrollToUsers() {
    // Prebaci se na stranicu sa proizvodima
    this.router.navigate(['/user']).then(() => {
      // Nakon navigacije, koristi setTimeout kako bi sačekao da se stranica učita
      setTimeout(() => {
        const element = document.getElementById('user-section');
        if (element) {
          const yOffset = 0; // Offset od 70px
          const yPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
          window.scrollTo({ top: yPosition, behavior: 'smooth' });
        }
      }, 200); // Sačekaj 0 milisekundi, ali dovoljno da se DOM učita
    });
  }
  
  

  getImageUrl(imagePath: string): string {
    return `http://localhost:3000/img/${imagePath}`;
  }

  // loadProducts(): void {
  //   this.http.get<Product[]>('http://localhost:3000/product')
  //     .subscribe(data => {
  //       this.products = data;
  //       this.filteredProducts = data; // Inicijalizuj filteredProducts sa učitanim proizvodima
  //     });
  // }

  loadProducts(): void {
    this.http.get<Product[]>('http://localhost:3000/product')
      .subscribe(data => {
        this.products = data.map(product => ({
          ...product,
          quantityToAdd: 1 ,// Inicijalizuj quantityToAdd na 1
          newPrice: 1,
          
        }));
        this.filteredProducts = this.products; // Inicijalizuj filteredProducts sa učitanim proizvodima

        this.products.forEach(product => {
          this.checkProductInCart(product.id); // Pozivamo metodu za proveru
        });
        
      });



      



      
      
  }


















  get uniqueTypes() {
    return Array.from(new Set(this.products.map(product => product.type)));
  }

  filterProducts() {
    this.filteredProducts = this.products.filter(product =>
      (this.selectedType ? product.type === this.selectedType : true) &&
      (this.searchTerm ? product.name.toLowerCase().includes(this.searchTerm.toLowerCase()) : true)
    );
  
    
  }
  updateQuantity(productId: number, newQuantity: number | undefined) {
    if(newQuantity!=undefined)
    this.productService.updateProductQuantity(productId, newQuantity)
      .subscribe({
        next: (result: any) => {
          console.log('Količina uspešno ažurirana:', result);
          this.loadProducts();

        },
        error: (error) => {
          console.error('Greška prilikom ažuriranja količine:', error);
        },
      });
  }

  updatePrice(productId: number, newPrice: number | undefined) {
    if(newPrice!=undefined)
    this.productService.updateProductPrice(productId, newPrice)
      .subscribe({
        next: (result: any) => {
          console.log('Cena uspešno ažurirana:', result);
          this.loadProducts();
        },
        error: (error) => {
          console.error('Greška prilikom ažuriranja cene:', error);
        },
      });
  }
  

  openConfirmDialog(productId:number): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: { name: 'Potvrda brisanja', description: 'Da li ste sigurni da želite da obrišete ovaj proizvod?' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteProduct(productId);
      }
    });
  }
   
  deleteProduct(id: number): void {
    this.productService.deleteProduct(id).subscribe({
      next: (response) => {
        console.log('Proizvod obrisan:', response);
        this.loadProducts();
        // Ovdje možeš dodati kod za obaveštavanje korisnika ili osvežavanje liste proizvoda
      },
      error: (error) => {
        console.error('Greška prilikom brisanja proizvoda:', error);
      }
    });
  }


  onFileSelected(event: any): void {
    const file = event.target.files[0]; // Dobij izabrani fajl
  
    if (file && file.type.startsWith('image/')) {
      this.selectedImage = file; // Postavi fajl u promenljivu
      this.productForm.patchValue({
        image: file
      });
      this.productForm.get('image')?.updateValueAndValidity(); // Osvetli validaciju za polje
    } else {
      console.error('Pogrešan format fajla, očekuje se slika.');
      this.productForm.patchValue({
        image: null
      });
    }
  
    // Proveri da li je slika postavljena
    console.log('Selected Image:', this.selectedImage);
  }
  
  

  onSubmit(): void {
    if (this.productForm.value.quantity < 0 || !Number.isInteger(this.productForm.value.quantity)) {
      alert('Količina mora biti pozitivan ceo broj');
      return;
  }
    if (this.productForm.valid && this.selectedImage) {
      const createProductDto:Product= {
        id: 0, // Generiše se na backendu
        name: this.productForm.value.name,
        type: this.productForm.value.type,
        price: this.productForm.value.price,
        quantity: this.productForm.value.quantity,
        image: '',
      };

      this.productService.createProduct(createProductDto, this.selectedImage)
        .subscribe({
          next: (product) => {
            console.log('Product created successfully:', product);
            this.loadProducts();
            // Uspešan unos (dodaj npr. redirekciju ili poruku korisniku)
          },
          error: (error) => {
            console.error('Error creating product:', error);
          },
        });
    }
    else{
      console.log(this.productForm.valid +" da " +this.selectedImage);
      console.log('Forma nije validna');
    Object.keys(this.productForm.controls).forEach(key => {
      const controlErrors = this.productForm.get(key)?.errors;
      if (controlErrors) {
        console.log(`Greške u ${key}:`, controlErrors);
      }
    });
  

    }
  }



}