import { StoreModule } from '@ngrx/store';
//import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { provideRouter, RouterModule } from '@angular/router';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { routes } from './app.routes';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
//import { CoreModule } from './core/core.module';
import { EffectsModule } from '@ngrx/effects';
import { CoreModule } from './core/core.module';
import { HttpClientModule } from '@angular/common/http';
import { ProductsModule } from './features/products/product.module';
import { ServicesModule } from './features/services/service.module';
import { UsersModule } from './features/user/user.module';
import { authReducer } from './auth/auth.reducer';
import { CartModule } from './features/cart/cart.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OrderModule } from './features/orders/order.module';


@NgModule({
  declarations: [AppComponent],
  imports: [
    CommonModule,
    BrowserModule,
    StoreModule.forRoot({auth: authReducer}, {}),
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument({ maxAge: 25 }),
    RouterModule.forRoot(routes),
    MatDialogModule,
    MatButtonModule,
    BrowserAnimationsModule,
    CoreModule,//isto...
    
    //ProductsModule,//istoooo
    //ServicesModule, //isti razlog kao usermodule... kad sam ubacio userRole u cosntr trazilo mi da izbacim
    CartModule,
    FormsModule,
    OrderModule,
     
    //UsersModule sam izbacio zasto nemam pojma
    //HttpClientModule,
    
    // ostali moduli
  ],
  bootstrap: [AppComponent],
  exports:[RouterModule]
  //providers: [provideAnimations(), provideRouter(routes)]
})export class AppModule {}