import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DeleteResult, Repository, UpdateResult } from 'typeorm';
import { CartItem } from './cartItem.entity';
import { CreateCartItemDto } from './cartItem.dtoc';
import { Observable, catchError, from, switchMap, throwError } from 'rxjs';
import { Cart } from 'src/cart/cart.entity';
import { Product } from 'src/product/product.entity';
import { Service } from 'src/service/service.entity';

@Injectable()export class CartItemService {
  constructor(
    @InjectRepository(CartItem)
    private cartItemRepository: Repository<CartItem>,
    @InjectRepository(Cart)
    private cartRepository: Repository<Cart>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(Service)
    private serviceRepository: Repository<Service>
  ) {}
  
  async findAllByCartId(cartId: number): Promise<CartItem[]> {
    return this.cartItemRepository.find({
      where: { cart: { id: cartId } },
      relations: ['product', 'service'], // Ako želiš da učitaš povezane entitete
    });
  }


  create(createCartItemDto: CreateCartItemDto): Observable<CartItem> {
    const { cartId, productId, serviceId, quantity, ...cartItemData } = createCartItemDto;
  
    if (quantity <= 0) {
      return throwError(() => new Error('Količina mora biti pozitivna'));
    }
  
    return from(this.cartRepository.findOne({ where: { id: cartId } })).pipe(
      switchMap((cart) => {
        if (!cart) {
          return throwError(() => new Error('Korpa nije pronađena'));
        }
  
        
        if (productId) {
          return from(this.productRepository.findOne({ where: { id: productId } })).pipe(
            switchMap((product) => {
              if (!product) {
                return throwError(() => new Error('Proizvod nije pronađen'));
              }
  
              const cartItem = this.cartItemRepository.create({
                ...cartItemData,
                cart,
                product,
                service: null,
                quantity,
              });
  
              return from(this.cartItemRepository.save(cartItem));
            })
          );
        } else if (serviceId) {
          return from(this.serviceRepository.findOne({ where: { id: serviceId } })).pipe(
            switchMap((service) => {
              if (!service) {
                return throwError(() => new Error('Usluga nije pronađena'));
              }
  
              const cartItem = this.cartItemRepository.create({
                ...cartItemData,
                cart,
                product: null,
                service,
                quantity,
              });
  
              return from(this.cartItemRepository.save(cartItem));
            })
          );
        } else {
          return throwError(() => new Error('Proizvod ili usluga mora biti postavljena'));
        }
      }),
      catchError((error) => throwError(() => error)),
    );
  }

  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem> {
    // Prvo nađi stavku u korpi
    const cartItem = await this.cartItemRepository.findOne({
      where: { id: id }, // Koristimo 'where' da specificiramo uslove
    });
    
    if (!cartItem) {
      throw new Error('Cart item not found');
    }
    
    // Ažuriraj količinu
    cartItem.quantity = quantity;

    // Sačuvaj izmenjenu stavku
    return this.cartItemRepository.save(cartItem);
  }
  

  getAllCartItems(): Observable<CartItem[]> {
    return from(this.cartItemRepository.find());
  }

  getCartItem(id: number): Observable<CartItem> {
    return from(this.cartItemRepository.findOne({ where: { id: id } }));
  }

  updateCartItem(id: number, cartItem: CartItem): Observable<UpdateResult> {
    return from(this.cartItemRepository.update(id, cartItem));
  }

  deleteCartItem(id: number): Observable<DeleteResult> {
    return from(this.cartItemRepository.delete(id));
  }
 

  async deleteCartItemsByCartAndProductId(cartId: number, productId: number): Promise<DeleteResult> {
    // Pronađi stavke koje imaju taj cartId i productId
    const items = await this.cartItemRepository.find({
      where: { cart: { id: cartId }, product: { id: productId } },
    });
    
    // Ako nema takvih stavki, baci grešku
    if (!items || items.length === 0) {
      throw new Error(`Nema stavki u korpi sa proizvodom ID: ${productId} i korpom ID: ${cartId}`);
    }

    // Obrisi stavke koje odgovaraju kombinaciji cartId i productId
    return this.cartItemRepository.delete({ cart: { id: cartId }, product: { id: productId } });
  }

  async isProductInCart(cartId: number, productId: number): Promise<boolean> {
    const cartItem = await this.cartItemRepository.findOne({
      where: { cart: { id: cartId }, product: { id: productId } },
    });

    // Ako postoji stavka, vrati true, u suprotnom false
    return !!cartItem;
  }

  async deleteCartItemsByCartAndServiceId(cartId: number, serviceId: number): Promise<DeleteResult> {
    // Pronađi stavke koje imaju taj cartId i productId
    const items = await this.cartItemRepository.find({
      where: { cart: { id: cartId }, service: { id: serviceId } },
    });
    
    // Ako nema takvih stavki, baci grešku
    if (!items || items.length === 0) {
      throw new Error(`Nema stavki u korpi sa uslugom ID: ${serviceId} i korpom ID: ${cartId}`);
    }

    // Obrisi stavke koje odgovaraju kombinaciji cartId i productId
    return this.cartItemRepository.delete({ cart: { id: cartId }, service: { id: serviceId } });
  }

  async isServiceInCart(cartId: number, serviceId: number): Promise<boolean> {
    const cartItem = await this.cartItemRepository.findOne({
      where: { cart: { id: cartId }, service: { id: serviceId } },
    });

    // Ako postoji stavka, vrati true, u suprotnom false
    return !!cartItem;
  }




  async deleteCartItemsByCartId(cartId: number): Promise<DeleteResult> {
    // Pronađi stavke koje imaju taj cartId 
    const items = await this.cartItemRepository.find({
      where: { cart: { id: cartId } },
    });
    
    // Ako nema takvih stavki, baci grešku
    if (!items || items.length === 0) {
      throw new Error(`Nema stavki u korpi sa  ID: ${cartId}`);
    }

    // Obrisi stavke koje odgovaraju kombinaciji cartId i productId
    return this.cartItemRepository.delete({ cart: { id: cartId } });
  }


  async isNotEmptyCart(cartId: number): Promise<boolean> {
    const cartItem = await this.cartItemRepository.findOne({
      where: { cart: { id: cartId }},
    });

    // Ako postoji stavka, vrati true, u suprotnom false
    return !!cartItem;
  }
  
}