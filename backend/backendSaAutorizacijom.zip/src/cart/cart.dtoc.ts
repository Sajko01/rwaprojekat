
export class CreateCartDto {
    id: number;
    userEmail: string;
    location: string;
}

