import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DeleteResult, Repository, UpdateResult } from 'typeorm';
import { Order } from './order.entity';
import { CreateOrderDto } from './order.dtoc';
import { Observable, catchError, from, map, mergeMap, of, reduce, switchMap, throwError } from 'rxjs';
import { User } from 'src/user/user.entity';
import { Cart } from 'src/cart/cart.entity';
import { CartItem } from 'src/cartitem/cartItem.entity';
import { Product } from 'src/product/product.entity';
import { Service } from 'src/service/service.entity';
import { OrderItem } from 'src/orderitem/orderitem.entity';
@Injectable()export class OrderService {
  constructor(
    @InjectRepository(Order)
    private orderRepository: Repository<Order>,
    @InjectRepository(OrderItem)
    private orderItemRepository: Repository<OrderItem>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Cart)
    private cartRepository: Repository<Cart>,
    //@InjectRepository(CartItem)
    //private cartItemRepository: Repository<CartItem>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(Service)
    private serviceRepository: Repository<Service>,
  ) {}


  async getOrdersByUserEmail(userEmail: string): Promise<Order[]> {
    // Vraća sve narudžbine za korisnika sa njegovim stavkama (orderItems)
    return this.orderRepository.find({
      where: { user: { email: userEmail } },
      relations: ['orderItems'], // Uključuje orderItems u rezultat
      order: { orderDate: 'DESC' },
    });
  }  

  async getAllOrdersForAdmin(): Promise<Order[]> {
    // Vraća sve narudžbine za korisnika sa njegovim stavkama (orderItems)
    return this.orderRepository.find({
      relations: ['orderItems'], // Uključuje orderItems u rezultat
      order: { orderDate: 'DESC' },
    });
  }  


  create(createOrderDto: CreateOrderDto): Observable<Order> {
    const { userEmail, cartId, ...orderData } = createOrderDto;

    return from(this.userRepository.findOne({ where: {email: userEmail} })).pipe(
      switchMap((user) => {
        if (!user) {
          return throwError(() => new Error('Korisnik nije pronađen'));
        }

        return from(this.cartRepository.findOne({ where: { id: cartId }, relations: ['cartItems'] })).pipe(
          switchMap((cart) => {
            if (!cart) {
              
              return throwError(() => new Error('Korpa nije pronađena'));
            }
           // orderLocation=cart.location;

            // Izračunaj ukupnu cenu na osnovu CartItem stavki
            return from(this.calculateTotalPrice(cart.cartItems)).pipe(
              switchMap((totalPrice,orderLocation) => {
                const order = this.orderRepository.create({
                  ...orderData,
                  user,
                  cart,
                  totalPrice,
                  orderLocation:cart.location,
                });

                return from(this.orderRepository.save(order)).pipe(
                  switchMap((savedOrder) => {
                    // Kreiranje OrderItems na osnovu CartItems
                    const orderItems = cart.cartItems.map((cartItem) => {




                     // dodatoo za smanjenej kolicine 
                     if (cartItem.product) {
                      // Smanji količinu proizvoda za količinu u stavci korpe
                      cartItem.product.quantity -= cartItem.quantity;

                      // Ažuriraj proizvod u bazi
                      this.productRepository.save(cartItem.product).then((updatedProduct) => {
                        console.log('Proizvod ažuriran:', updatedProduct);
                      })
                      .catch((error) => {
                        console.error('Greška prilikom ažuriranja količine proizvoda:', error);
                      });
                  }




                     //dodatoo 





                      return this.orderItemRepository.create({
                        order: savedOrder,
                        product: cartItem.product,
                        service: cartItem.service,
                        quantity: cartItem.quantity,
                        addInfo: cartItem.addInfo,
                      });
                    });
  
                    // Sačuvaj sve OrderItems
                    return from(this.orderItemRepository.save(orderItems)).pipe(
                      map(() => savedOrder) // Vrati narudžbinu kada su OrderItems sačuvani
                    );
                  })
                );
              })
            );
          })
        );
      }),
      catchError((error) => throwError(() => error)),
    );
  }

  private calculateTotalPrice(cartItems: CartItem[]): Observable<number> {
    return from(cartItems).pipe(
      mergeMap((cartItem) => {
        if (cartItem.product) {
        //  cartItem.product.quantity-=cartItem.quantity;//PROVERIIIIIIIIIIII
          return from(this.productRepository.findOne({ where: { id: cartItem.product.id } })).pipe(
            map((product) => product ? product.price * cartItem.quantity : 0)
          );
        } else if (cartItem.service) {
          return from(this.serviceRepository.findOne({ where: { id: cartItem.service.id } })).pipe(
            map((service) => service ? service.pricePerUnit * cartItem.quantity : 0)
          );
        }
        return of(0);
      }),
      reduce((acc, price) => acc + price, 0)  // Saberi ukupnu cenu
    );
  }

  getAllOrders(): Observable<Order[]> {
    return from(this.orderRepository.find());
  }

  getOrder(id: number): Observable<Order> {
    return from(this.orderRepository.findOne({ where: { id: id } }));
  }
  getOrdersForUser(idUser: number): Observable<Order[]> {
    return from(this.userRepository.findOne({ where: { id: idUser }, relations: ['orders'] })).pipe(
      switchMap((user) => {
        if (!user) {
          return throwError(() => new Error('Korisnik nije pronađen.'));
        }

        return from(this.orderRepository.find({ where: { user: { id: user.id } }, relations: ['orderItems', 'cart'] })).pipe(
          switchMap((orders) => {
            if (!orders || orders.length === 0) {
              return of([]); // Ako nema narudžbi, vraća prazan niz
            }
            return of(orders);
          }),
          catchError((error) => throwError(() => error))
        );
      }),
      catchError((error) => throwError(() => error))
    );
  }

  updateOrder(id: number, order: Order): Observable<UpdateResult> {
    return from(this.orderRepository.update(id, order));
  }

  deleteOrder(id: number): Observable<DeleteResult> {
    return from(this.orderRepository.delete(id));
  }

  // Metod za brisanje porudžbine po ID-ju
  // async deleteOrderById(orderId: number): Promise<void> {
  //   const order = await this.orderRepository.findOne({ where: { id: orderId } });

  //   if (!order) {
  //     throw new NotFoundException(`Order with ID ${orderId} not found`);
  //   }

  //   // Proveravamo da li je prošlo više od 5 minuta
  //   const now = new Date();
  //   const fiveMinutes = 5 * 60 * 1000; // 5 minuta u milisekundama
  //   const timeDifference = now.getTime() - new Date(order.orderDate).getTime();

  //   if (timeDifference > fiveMinutes) {
  //     throw new BadRequestException('You can only delete the order within 5 minutes of creation.');
  //   }

  //   await this.orderRepository.remove(order);
  // }

  async deleteOrderById(orderId: number): Promise<void> {
    const order = await this.orderRepository.findOne({ where: { id: orderId }, relations: ['orderItems'] });
  
    if (!order) {
      throw new NotFoundException(`Order with ID ${orderId} not found`);
    }
  
    // Proveravamo da li je prošlo više od 5 minuta
    const now = new Date();
    const fiveMinutes = 5 * 60 * 1000; // 5 minuta u milisekundama
    const timeDifference = now.getTime() - new Date(order.orderDate).getTime();
  
    if (timeDifference > fiveMinutes) {
      throw new BadRequestException('You can only delete the order within 5 minutes of creation.');
    }
  
    // Prolazimo kroz OrderItem-e i vraćamo količinu proizvoda
    for (const orderItem of order.orderItems) {
      if (orderItem.product) { // Proveravamo da li je OrderItem povezan sa proizvodom
        orderItem.product.quantity += orderItem.quantity;
  
        // Ažuriramo proizvod u bazi
        await this.productRepository.save(orderItem.product);
      }
    }
  
    // Nakon ažuriranja proizvoda, brišemo narudžbinu
    await this.orderRepository.remove(order);
  }



}