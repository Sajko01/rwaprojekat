export class ServiceDto {
    id: number;
    name: string;
    image: String;
    pricePerUnit:number;
    description:string;
}


  