export class CreateServiceDto {
    id: number;
    name: string;
    image: string;
    pricePerUnit:number;
    description:string;
}


  