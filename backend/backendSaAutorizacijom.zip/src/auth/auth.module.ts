import { forwardRef, Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { AuthService } from './auth.service';
import { UserModule } from 'src/user/user.module';
import { LocalStrategy } from './local.strategy';
import { JwtStrategy } from './jwt.strategy';
import { RolesGuard } from 'src/role/roles.guard';

@Module({
  imports: [
    forwardRef(() => UserModule),
    PassportModule,
    JwtModule.register({
      secret: 'tvoja_tajna', // tvoj tajni ključ
      signOptions: { expiresIn: '1h' }, // opcije za potpisivanje tokena
    }),
  ],
  providers: [AuthService, LocalStrategy, JwtStrategy,RolesGuard],//5o dodato RoelsGuard
  exports: [AuthService],
})
export class AuthModule {}



// // Radno
// import { forwardRef, Module } from '@nestjs/common';
// import { AuthService } from './auth.service';
// import { UserModule } from 'src/user/user.module';  // Važno da imamo pristup UserService

// @Module({
//   imports: [forwardRef(() =>UserModule)], // Importuješ UserModule da možeš koristiti UserService
//   providers: [AuthService],
//   exports: [AuthService],
// })
// export class AuthModule {}







// import { Module } from '@nestjs/common';
// import { AuthController } from './auth.controller';
// import { AuthService } from './auth.service';
// import { JwtModule } from '@nestjs/jwt';
// import { PassportModule } from '@nestjs/passport';
// import { LocalStrategy } from './local.strategy';
// import { JwtStrategy } from './jwt.strategy';
// import { User } from 'src/user/user.entity';
// import { TypeOrmModule } from '@nestjs/typeorm';

// @Module({
//   imports: [
//     TypeOrmModule.forFeature([User]),
//     PassportModule,
//     JwtModule.register({
//       secret: 'OVOJEMOJSKRIVENIKLJUCKOJINETREBADADELIMNISAKIM',
//       signOptions: { expiresIn: '1h' },
//     }),
//   ],
//   controllers: [AuthController],
//   providers: [AuthService, LocalStrategy, JwtStrategy],
// })
// export class AuthModule {}


// import { Module } from '@nestjs/common';
// import { AuthService } from './auth.service';
// import { UserModule } from '../user/user.module';
// import { JwtModule } from '@nestjs/jwt';
// import { PassportModule } from '@nestjs/passport';
// import { JwtStrategy } from './jwt.strategy';
// import { LocalStrategy } from './local.strategy';
// import { AuthController } from './auth.controller';
// import { ConfigModule, ConfigService } from '@nestjs/config';

// @Module({
//   imports: [
//     UserModule,
//     PassportModule,
//     JwtModule.registerAsync({
//       imports: [ConfigModule],
//       inject: [ConfigService],
//       useFactory: async (configService: ConfigService) => ({
//         secret: configService.get('JWT_SECRET'),
//         signOptions: { expiresIn: '60m' }, // Token traje 60 minuta
//       }),
//     }),
//   ],
//   providers: [AuthService, LocalStrategy, JwtStrategy],
//   controllers: [AuthController],
// })
// export class AuthModule {}
