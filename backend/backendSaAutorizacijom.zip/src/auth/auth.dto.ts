export class AuthPayloadDto {
  email: string;

  password: string;
}

//da bi implentira passport.js za nodeJS nisu dovolji module i atuh service vec mora da ima i jwt ili lokalna strategija.. 
// Lokalna strategija će se koristiti prilikom prijave korisnika putem email-a i lozinke.
// JWT strategija će se koristiti za zaštitu API ruta nakon što korisnik dobije JWT token.
// Sada imaš oba sistema autentifikacije implementirana.

// AuthController: Ako koristiš samo login funkcionalnost, možeš imati samo jedan kontroler koji poziva AuthService i omogućava prijavu korisnika.

// LocalStrategy i JwtStrategy: Ove strategije su potrebne ako želiš da koristiš Passport za dodatne mogućnosti autentifikacije, kao što su zaštita određenih ruta. Ako koristiš samo JWT za prijavu, možda ti neće biti potrebne.

// AuthGuard: Ovaj fajl se koristi za zaštitu ruta. Ako ne planiraš da implementiraš zaštitu ruta, onda ti ovaj fajl možda nije potreban.