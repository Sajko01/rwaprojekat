import { Strategy } from 'passport-local';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';

@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy) {
  constructor(private authService: AuthService) {
    super({ usernameField: 'email' }); // Možeš koristiti 'email' umesto 'username'
  }

  async validate(email: string, password: string): Promise<any> {
    console.log(`Validating user: ${email}`);//cisto za proveru validacije ispisuje se u konzoli tako da vidimo da se koristi 
    //DA SE RAZJASNI MOZES PITATI STA SE DESAVA KAD SE UDJE U ONO USEGUARD(LOCALSTRATEGY)...
    const user = await this.authService.validateUser(email, password);
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }
    return user; // Passport će automatski staviti ovog korisnika u req.user
  }
}





// import { PassportStrategy } from '@nestjs/passport';
// import { Strategy } from 'passport-local';
// import { AuthService } from './auth.service';
// import { Injectable, UnauthorizedException } from '@nestjs/common';

// @Injectable()
// export class LocalStrategy extends PassportStrategy(Strategy) {
//   constructor(private authService: AuthService) {
//     super();
//   }

//   validate(email: string, password: string) {
//     const user = this.authService.validateUser({ email, password });
//     if (!user) throw new UnauthorizedException();
//     return user;
//   }
// }


// import { Strategy } from 'passport-local';
// import { PassportStrategy } from '@nestjs/passport';
// import { Injectable, UnauthorizedException } from '@nestjs/common';
// import { AuthService } from './auth.service';

// @Injectable()
// export class LocalStrategy extends PassportStrategy(Strategy) {
//   constructor(private authService: AuthService) {
//     super();
//   }

//   async validate(username: string, password: string): Promise<any> {
//     const user = await this.authService.validateUser(username, password);
//     if (!user) {
//       throw new UnauthorizedException();
//     }
//     return user;
//   }
// }
