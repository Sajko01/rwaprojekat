import { Controller, Post, UseGuards, Request } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LocalAuthGuard } from './local-auth.guard';
import { JwtAuthGuard } from './jwt-auth.guard';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @UseGuards(LocalAuthGuard)//evo gde se koristi vec localauthguard samim tim i local strategy 
  @Post('login')
  async login(@Request() req) {
    return this.authService.login(req.user);
  }

  @UseGuards(JwtAuthGuard)//ovo je nacin da se koristi jwt auth guard 
  @Post('profile')
  getProfile(@Request() req) {
    return req.user;
  }
}




// import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
// import { AuthPayloadDto } from './auth.dto';
// import { AuthService } from './auth.service';
// import { LocalGuard } from './local.guard';
// import { Request } from 'express';
// import { JwtAuthGuard } from './jwt.guard';

// @Controller('auth')
// export class AuthController {
//   constructor(private authService: AuthService) {}

//   @Post('login')
//   @UseGuards(LocalGuard)
//   login(@Req() req: Request) {
//     return req.user;
//   }

//   @Get('status')
//   @UseGuards(JwtAuthGuard)
//   status(@Req() req: Request) {
//     return req.user;
//   }
// }




// import { Controller, Post, Body } from '@nestjs/common';
// import { AuthService } from './auth.service';
// import { AuthDto } from './auth.dto';

// @Controller('auth')
// export class AuthController {
//   constructor(private authService: AuthService) {}

//   @Post('login')
//   async login(@Body() authDto: AuthDto) {
//     return this.authService.login(authDto);
//   }
// }
