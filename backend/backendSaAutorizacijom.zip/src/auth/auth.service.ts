import * as jwt from 'jsonwebtoken';
import { forwardRef, Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { UserService } from 'src/user/user.service';
import { AuthPayloadDto } from './auth.dto';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  private readonly JWT_SECRET = 'tvoja_tajna';

  constructor(
    @Inject(forwardRef(() => UserService)) private userService: UserService,
    private jwtService: JwtService
  ) {}
 


  async validateUser(email: string, password: string): Promise<any> {
    const user = await this.userService.validateUser(email, password);
    if (user) {
      return user;
    }
    return null; // Vraća null umesto exception-a zbog Passport strategije
  }

  async login(authDto: AuthPayloadDto): Promise<any> {
    const user = await this.validateUser(authDto.email, authDto.password);
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }
    const payload = { email: user.email, sub: user.id ,role:user.role};
    return {
      access_token: this.jwtService.sign(payload),
      email: authDto.email,
      role:user.role
      
    };
  }

  generateToken(payload: any): string {
    return this.jwtService.sign(payload);
  }

  verifyToken(token: string): any {
    try {
      return this.jwtService.verify(token, { secret: this.JWT_SECRET });
    } catch (e) {
      throw new UnauthorizedException('Invalid token');
    }
  }
}




// // Radno
// import * as jwt from 'jsonwebtoken';
// import { forwardRef, Inject, Injectable, UnauthorizedException } from '@nestjs/common';
// import { UserService } from 'src/user/user.service';
// import { AuthPayloadDto } from './auth.dto';

// @Injectable()
// export class AuthService {
//   private readonly JWT_SECRET = 'tvoja_tajna';
   
//   //ForwardRef zbog uzajamnih zavisnosti koristi se user u auth i obrnuto...
//   constructor(@Inject(forwardRef(() => UserService))private userService: UserService) {}

//   async validateUser(email: string, password: string): Promise<any> {
//     const user = await this.userService.validateUser(email, password);
//     if (user) {
//       return user;
//     }
//     throw new UnauthorizedException('Invalid credentials');
//   }

//   async login(authDto: AuthPayloadDto): Promise<any> {
//     const user = await this.validateUser(authDto.email, authDto.password);
//     const payload = { email: user.email, sub: user.id };
//     return {
//       access_token: this.generateToken(payload),
//       email: authDto.email,
//     };
//   }

//   generateToken(payload: any): string {
//     return jwt.sign(payload, this.JWT_SECRET, { expiresIn: '1h' });
//   }

//   verifyToken(token: string): any {
//     try {
//       return jwt.verify(token, this.JWT_SECRET);
//     } catch (e) {
//       throw new UnauthorizedException('Invalid token');
//     }
//   }
// }


// import { Injectable, NotFoundException } from '@nestjs/common';
// import { AuthPayloadDto } from './auth.dto';
// import { JwtService } from '@nestjs/jwt';
// import { InjectRepository } from '@nestjs/typeorm';
// import { Repository } from 'typeorm';
// import { User } from 'src/user/user.entity';
// import * as bcrypt from 'bcrypt';

// @Injectable()
// export class AuthService {
//   constructor(
//     private jwtService: JwtService,
//     @InjectRepository(User)
//     private usersRepository: Repository<User>,
//   ) {}

//   async validateUser({ email, password }: AuthPayloadDto) {
//     const user = await this.usersRepository.findOne({ where: {email: email} });

//     if (!user) {
//       throw new NotFoundException('User nije pronadjen');
//     }
//     const isPasswordValid = await bcrypt.compare(password, user.password);

//     if (isPasswordValid) {
//       const { password, ...userWithoutPassword } = user;
//       return { token: this.jwtService.sign(userWithoutPassword) };
//     }

//     return null;
//   }
// }



// import { Injectable } from '@nestjs/common';
// import { JwtService } from '@nestjs/jwt';
// import { UserService } from '../user/user.service';
// import * as bcrypt from 'bcrypt';
// import { AuthDto } from './auth.dto';

// @Injectable()
// export class AuthService {
//   constructor(
//     private userService: UserService,
//     private jwtService: JwtService,
//   ) {}

//   async validateUser(username: string, pass: string): Promise<any> {
//     const user = await this.userService.getUserByUsername(username);
//     if (user && await bcrypt.compare(pass, user.)) {
//       const { password, ...result } = user;
//       return result;
//     }
//     return null;
//   }

//   async login(authDto: AuthDto) {
//     const { username, password } = authDto;
//     const user = await this.validateUser(username, password);
//     if (!user) {
//       throw new Error('Invalid credentials');
//     }

//     const payload = { username: user.username, sub: user.id };
//     return {
//       access_token: this.jwtService.sign(payload),
//     };
//   }
// }
