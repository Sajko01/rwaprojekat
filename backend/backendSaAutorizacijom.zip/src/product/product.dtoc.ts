export class CreateProductDto {
    id: number;
    name: string;
    type: string;
    image: string;
    quantity: number;
    price:number;
}

