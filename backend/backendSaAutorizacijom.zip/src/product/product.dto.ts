
export class ProductDto {
    id: number;
    name: string;
    type: string;
    image: String;
    quantity: number;
    price:number;
}

