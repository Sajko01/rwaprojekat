import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as path from 'path'; // Dodaj ovo za import
import { NestExpressApplication } from '@nestjs/platform-express';

async function bootstrap() {
  //const app = await NestFactory.create(AppModule);// dodao ovo u okviru<>, ako nesto nece odma resi

  
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  // Omogući serviranje statičkih fajlova iz public direktorijuma
  app.useStaticAssets(path.join(__dirname, '..', 'public'));
  app.enableCors();
  await app.listen(3000);
}
bootstrap();










//PROMENA, 1
// import { NestFactory } from '@nestjs/core';
// import { AppModule } from './app.module';

// async function bootstrap() {
//   const app = await NestFactory.create(AppModule);
//   app.enableCors(); //SAMO OVO JE DODATO
//   await app.listen(3000);
// }
// bootstrap();
