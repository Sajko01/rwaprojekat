import { Body, Controller, Delete, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { User, UserRole } from './user.entity';
import { UserService } from './user.service';
import { CreateUserDto } from './user.dtoc';
import { Observable } from 'rxjs';
import { DeleteResult, UpdateResult } from 'typeorm';
import { AuthPayloadDto } from 'src/auth/auth.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RolesGuard } from 'src/role/roles.guard';
import { Roles } from 'src/role/roles.decorator';
import { LocalAuthGuard } from 'src/auth/local-auth.guard';


@Controller('user')export class UserController {
  constructor(private userService: UserService) {}
  // Ruta za registraciju
  @Post('register')
  registerUser(@Body() user: CreateUserDto): Observable<User> {
    if (!user.role) {
      user.role = UserRole.USER; // Ili neka druga default vrednost
  }
    return this.userService.create(user);
  }

  // Ruta za prijavu
  //@UseGuards(JwtAuthGuard, RolesGuard)
 // @Roles(UserRole.ADMIN)//Samo ovo po sebi bez gore nista ne vazi.....
  @UseGuards(LocalAuthGuard)//Paznja paznja, nije u authcontroler kod mene je ovde //RADI JER PREKO LOCALAUTH GUARD UDJE U LOCACL STRATEGY ITD....
  @Post('login')
  async login(@Body() authDto: AuthPayloadDto): Promise<any> {
    return this.userService.login(authDto);
  }


  @UseGuards(JwtAuthGuard, RolesGuard)//ovo je 6o poslednje dodato kao primer
  @Roles(UserRole.ADMIN)
  @Post('admin-only')
  adminOnlyRoute() {
    return 'Ovo je ruta samo za admin korisnike';
  }


  // @Post()
  // create(@Body() user: CreateUserDto): Observable<User> {
  //   return this.userService.create(user);
  // }

  @Get()
  getAll(): Observable<User[]> {
    return this.userService.getAllUsers();
  }

  @Get(':id')
  getUser(@Param('id') id: number): Observable<User> {
    return this.userService.getUser(id);
  }

  @Put(':id')
  updateUser(
    @Param('id') id: number,
    @Body() user: User,
  ): Observable<UpdateResult> {
    return this.userService.updateUser(id, user);
  }

  @Delete(':id')
  deleteUser(@Param('id') id: number): Observable<DeleteResult> {
    return this.userService.deleteUser(id);
  }
}